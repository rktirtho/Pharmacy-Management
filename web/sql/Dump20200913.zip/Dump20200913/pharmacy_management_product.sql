-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: pharmacy_management
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `_name` varchar(255) NOT NULL,
  `_group` varchar(255) NOT NULL,
  `_description` tinytext,
  `_type` varchar(50) DEFAULT NULL,
  `batch_no` varchar(120) DEFAULT NULL,
  `unit_size` double NOT NULL,
  `unit_buying_prize` double(10,2) NOT NULL,
  `unit_selling_prize` double(10,2) NOT NULL,
  `profit_per_unit` double(10,2) NOT NULL,
  `_discount` double NOT NULL,
  `_quantity` int NOT NULL,
  `author_id` varchar(255) DEFAULT NULL,
  `inventor` varchar(255) NOT NULL,
  `is_updated` tinyint(1) DEFAULT '0',
  `is_available` tinyint(1) DEFAULT '1',
  `_expire_date` varchar(120) DEFAULT NULL,
  `_last_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (34,'Napa Extra','Peracitamole 500 + Cafain',NULL,'medicine','GT46FJ',1,0.80,1.50,0.00,3,500,'Beximco','rktirtho',0,1,'2020-09-19','2020-09-06 11:09:00'),(35,'Napa Extra','Peracitamole 500 + Cafain',NULL,'medicine','GFG4JHK',1,1.04,2.50,0.00,3,623,'Beximco','rktirtho',1,1,'2020-09-25','2020-09-06 11:10:18'),(36,'Napa','Peracitamole 500',NULL,'medicine','g5fhh',1,0.50,1.00,0.00,3,500,'Beximco','rktirtho',1,1,'2020-09-19','2020-09-06 11:12:17'),(37,'Ponds Fashwash','Fashwash',NULL,'medicine','gfg45g',1,180.00,220.00,0.00,5,50,'Ponds','rktirtho',1,1,'2020-10-02','2020-09-06 11:21:05'),(38,'Doxin','Doxixycline','4821132','medicine','HUDJ54D',1,2.00,2.20,0.00,1,4850,'GSK','rktirtho',1,1,'2020-10-02','2020-09-09 12:16:21'),(39,'M-Kast','Montilucast','783495','medicine','1656314',1,10.00,14.00,0.00,8,4990,'Orion','rktirtho',1,1,'2020-10-05','2020-09-11 03:29:09'),(40,'Savlon Handwash 200 ML','Savlon','787495','medicine','4DR',1,90.00,95.00,0.00,1,280,'ACI','rktirtho',1,1,'2020-10-10','2020-09-11 03:34:15'),(41,'fgf','fgfg',NULL,'medicine','211g',1,15.00,456.00,0.00,14,61,'dfgfg','rktirtho',1,1,'2020-09-22','2020-09-11 03:35:45'),(42,'gfg','fgf',NULL,'medicine','22fgf',1453,45654.00,43541.00,0.00,5545,5,'fgfg','rktirtho',1,1,'2020-09-22','2020-09-11 03:36:53'),(43,'dfdf','dfd','413212','medicine','dfd5f4',5,456.00,470.00,0.00,1,10,'gf','rktirtho',1,1,'2020-09-23','2020-09-11 03:38:22'),(44,'Pevison','estomaf','4752456','medicine','4554365',1,50.00,55.00,0.00,1,0,'Sanofi','test@gmail.com',1,1,NULL,'2020-09-12 14:12:55');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-13 17:02:21
